﻿$(document).ready(function () {
    $.ajax({
        type: 'GET',
        url: "/api/product",
        dataType: "json",
        success: fillTable,
        error: function (XMLHttpRequest, textStatus, errorThrown) {
            alert("AJAX ERROR: " + errorThrown);
        }
    });
});

function fillTable(data) {
    var tbody = $("<tbody></tbody>");
    var list = data == null ? [] : (data instanceof Array ? data : [data]);
    $.each(list, function (index, item) {
        console.log(item);
        var row = $("<tr></tr>");
        row.append($("<td>" + item.name + "</td>"));
        row.append($("<td>" + item.color + "</td>"));
        row.append($("<td>" + item.price + "</td>"));
        tbody.append(row);
    });
    $("#productsTable").append(tbody);
}
