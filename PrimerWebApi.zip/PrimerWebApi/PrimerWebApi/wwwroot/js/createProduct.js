﻿$(document).ready(function () {
    $("#createForm").submit(function (e) {
        e.preventDefault();

        if ($("#name").val().length < 1) {
            alert("Name should be defined!");
            return;
        }
        if ($("#color").val().length < 1) {
            alert("Color should be defined!");
            return;
        }
        if (isNaN($("#price").val()) || $("#price").val() <= 0) {
            alert("Price should be positive number!");
            return;
        }

        var that = $(this);

        $.ajax({
            type: 'POST',
            url: "/api/product",
            contentType: "application/json",
            data: formToJson(),
            success: function () {
                location.replace("/html/products.html");
            },
            error: function (XMLHttpRequest, textStatus, errorThrown) {
                alert("AJAX ERROR: " + errorThrown);
            }
        });
    });
});

function formToJson() {
    return JSON.stringify({
        "name": $("#name").val(),
        "color": $("#color").val(),
        "price": $("#price").val()
    });
}