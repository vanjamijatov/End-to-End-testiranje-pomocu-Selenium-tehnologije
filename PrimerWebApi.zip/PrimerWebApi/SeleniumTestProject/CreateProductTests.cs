﻿using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using System;
using Xunit;

namespace SeleniumTestProject
{

    public class CreateProductTests : IDisposable
    {
        private readonly IWebDriver driver;
        private Pages.ProductsPage productsPage;
        private Pages.CreateProductPage createProductPage;
        private int productsCount = 0;

        public CreateProductTests()
        {
            // options for launching Google Chrome
            ChromeOptions options = new ChromeOptions();
            options.AddArguments("start-maximized");            // open Browser in maximized mode
            options.AddArguments("disable-infobars");           // disabling infobars
            options.AddArguments("--disable-extensions");       // disabling extensions
            options.AddArguments("--disable-gpu");              // applicable to windows os only
            options.AddArguments("--disable-dev-shm-usage");    // overcome limited resource problems
            options.AddArguments("--no-sandbox");               // Bypass OS security model
            options.AddArguments("--disable-notifications");    // disable notifications

            driver = new ChromeDriver(options);

            
            productsPage = new Pages.ProductsPage(driver);      // create ProductsPage
            productsPage.Navigate();                            // navigate to url
            productsPage.EnsurePageIsDisplayed();               // wait for table to populate
            Assert.Equal("Products", productsPage.Title);       // check if title correct
            Assert.True(productsPage.LinkDisplayed());          // check if link displayed
            productsCount = productsPage.ProductsCount();       // get number of table rows - after create successful sheck if number increased
            productsPage.ClickLink();                           // click link and navigate to CreateProductPage

            createProductPage = new Pages.CreateProductPage(driver);        // create ProductsPage
            Assert.Equal("Create product", createProductPage.Title);
            Assert.Equal(driver.Url, Pages.CreateProductPage.URI);

            Assert.True(createProductPage.NameElementDisplayed());          // check if form input elements are displayed
            Assert.True(createProductPage.ColorElementDisplayed());
            Assert.True(createProductPage.PriceElementDisplayed());
            Assert.True(createProductPage.SubmitButtonElementDisplayed());
        }
        public void Dispose()
        {
            driver.Quit();
            driver.Dispose();
        }

        [Fact]
        public void TestInvalidName()
        {
            createProductPage.InsertColor("blue");          // insert all values except name
            createProductPage.InsertPrice("213.4");
            createProductPage.SubmitForm();

            createProductPage.WaitForAlertDialog();         // wait for alert dialog
            Assert.Equal(createProductPage.GetDialogMessage(), Pages.CreateProductPage.InvalidNameMessage);     // check if alert message expected
            createProductPage.ResolveAlertDialog();         // accept dialog
            Assert.Equal(driver.Url, Pages.CreateProductPage.URI);      // check if same url - page not submitted
        }

        [Fact]
        public void TestInvalidColor()
        {
            createProductPage.InsertName("jacket");          // insert all values except color
            createProductPage.InsertPrice("213.4");
            createProductPage.SubmitForm();

            createProductPage.WaitForAlertDialog();         // wait for alert dialog
            Assert.Equal(createProductPage.GetDialogMessage(), Pages.CreateProductPage.InvalidColorMessage);     // check if alert message expected
            createProductPage.ResolveAlertDialog();         // accept dialog
            Assert.Equal(driver.Url, Pages.CreateProductPage.URI);      // check if same url - page not submitted
        }

        [Fact]
        public void TestInvalidPrice()
        {
            createProductPage.InsertName("jacket");          // insert all values except price
            createProductPage.InsertColor("blue");
            createProductPage.SubmitForm();

            createProductPage.WaitForAlertDialog();         // wait for alert dialog
            Assert.Equal(createProductPage.GetDialogMessage(), Pages.CreateProductPage.InvalidPriceMessage);     // check if alert message expected
            createProductPage.ResolveAlertDialog();         // accept dialog
            Assert.Equal(driver.Url, Pages.CreateProductPage.URI);      // check if same url - page not submitted
        }

        [Fact]
        public void TestSuccessfulSubmit()
        {
            createProductPage.InsertName("jacket");                     // insert all values except price
            createProductPage.InsertColor("blue");
            createProductPage.InsertPrice("213.4");
            createProductPage.SubmitForm();
            createProductPage.WaitForFormSubmit();

            Pages.ProductsPage newProductsPage = new Pages.ProductsPage(driver);        // create ProductsPage
            Assert.Equal("Products", newProductsPage.Title);                            // check if correct title
            newProductsPage.EnsurePageIsDisplayed();                                    // wait for table to populate
            Assert.True(newProductsPage.LinkDisplayed());                               // check if link displayed

            Assert.Equal(productsCount + 1, newProductsPage.ProductsCount());           // check if number of rows increased       
            Assert.Equal("jacket", newProductsPage.GetLastRowName());                   // check if last product name valid
            Assert.Equal("blue", newProductsPage.GetLastRowColor());                    // check if last product color valid
            Assert.Equal("213.4", newProductsPage.GetLastRowPrice());                   // check if last product price valid
        }
    }
}
