﻿using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using System;
using System.Collections.Generic;
using System.Text;

namespace SeleniumTestProject.Pages
{
    public class CreateProductPage
    {
        private readonly IWebDriver driver;
        public const string URI = "http://localhost:51963/html/createProduct.html";
        private IWebElement NameElement => driver.FindElement(By.Id("name"));
        private IWebElement ColorElement => driver.FindElement(By.Id("color"));
        private IWebElement PriceElement => driver.FindElement(By.Id("price"));
        private IWebElement SubmitButtonElement => driver.FindElement(By.Id("submitButton"));
        public string Title => driver.Title;
        public const string InvalidNameMessage = "Name should be defined!";
        public const string InvalidColorMessage = "Color should be defined!";
        public const string InvalidPriceMessage = "Price should be positive number!";
        public CreateProductPage(IWebDriver driver)
        {
            this.driver = driver;
        }

        public bool NameElementDisplayed()
        {
            return NameElement.Displayed;
        }

        public bool ColorElementDisplayed()
        {
            return ColorElement.Displayed;
        }

        public bool PriceElementDisplayed()
        {
            return PriceElement.Displayed;
        }

        public bool SubmitButtonElementDisplayed()
        {
            return SubmitButtonElement.Displayed;
        }

        public void InsertName(string name)
        {
            NameElement.SendKeys(name);
        }

        public void InsertColor(string color)
        {
            ColorElement.SendKeys(color);
        }

        public void InsertPrice(string price)
        {
            PriceElement.SendKeys(price);
        }

        public void SubmitForm()
        {
            SubmitButtonElement.Click();
        }

        public void WaitForAlertDialog()
        {
            var wait = new WebDriverWait(driver, new TimeSpan(0, 0, 10));
            wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.AlertIsPresent());
        }

        public string GetDialogMessage()
        {
            return driver.SwitchTo().Alert().Text;
        }

        public void ResolveAlertDialog()
        {
            driver.SwitchTo().Alert().Accept();
        }

        public void WaitForFormSubmit()
        {
            var wait = new WebDriverWait(driver, new TimeSpan(0, 0, 20));
            wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.UrlToBe(ProductsPage.URI));
        }
    }
}
